from intro_to_flask import app
 
app.run(debug=True)